﻿using ProjetoMVC3A.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoMVC3A.BLL
{
    class tblMusicaBLL
    {
        // Conexão com o Banco de Dados - DAL - Data Acess Layer
        private DALBD daoBanco = new DALBD();

        public DataTable ListarMusicas()
        {
            string sql = string.Format($@"select * from tblMusica");
            return daoBanco.ExecutarConsulta(sql);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoMVC3A.DTO
{
    class tblCDDTO
    {
        private int idCD;
        private string nomeCD;
        private double precoVenda;
        private DateTime dtLancamento;

        public int IdCD { get => idCD; set => idCD = value; }
        public string NomeCD { get => nomeCD; set => nomeCD = value; }
        public double PrecoVenda { get => precoVenda; set => precoVenda = value; }
        public DateTime DtLancamento { get => dtLancamento; set => dtLancamento = value; }
    }
}

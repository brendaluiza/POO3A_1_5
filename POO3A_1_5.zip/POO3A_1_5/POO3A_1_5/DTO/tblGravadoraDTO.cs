﻿using System;

namespace ProjetoMVC3A.DTO
{
    class tblGravadoraDTO
    {
        private int idGravadora;
        private string nome;

        public int IdGravadora { get => idGravadora; set => idGravadora = value; }
        public string Nome { get => nome; set => nome = value; }
    }

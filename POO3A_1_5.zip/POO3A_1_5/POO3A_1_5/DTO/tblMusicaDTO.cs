﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoMVC3A.DTO
{
    class tblMusicaDTO
    {
        private int idMusica;
        private int idGravadora;
        private int idCD;
        private string nome;
        private string nomeAutor;

        public int IdMusica { get => idMusica; set => idMusica = value; }
        public int IdGravadora { get => idGravadora; set => idGravadora = value; }
        public int IdCD { get => idCD; set => idCD = value; }
        public string Nome { get => nome; set => nome = value; }
        public string NomeAutor { get => nomeAutor; set => nomeAutor = value; }
    }
